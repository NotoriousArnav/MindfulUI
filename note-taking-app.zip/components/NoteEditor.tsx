"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function NoteEditor({ note, onNoteUpdate }) {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")

  useEffect(() => {
    if (note) {
      setTitle(note.title)
      setContent(note.content.content)
    } else {
      setTitle("")
      setContent("")
    }
  }, [note])

  const handleSave = () => {
    if (note) {
      onNoteUpdate({
        ...note,
        title,
        content: { content },
        updated_at: new Date().toISOString(),
      })
    }
  }

  if (!note) {
    return (
      <div className="flex-1 p-4 flex items-center justify-center text-gray-500">
        Select a note or create a new one to start editing
      </div>
    )
  }

  return (
    <div className="flex-1 p-4 flex flex-col">
      <Input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Note title"
        className="text-2xl font-semibold mb-4"
      />
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Start writing your note here..."
        className="flex-1 resize-none mb-4"
      />
      <Button onClick={handleSave}>Save</Button>
    </div>
  )
}

